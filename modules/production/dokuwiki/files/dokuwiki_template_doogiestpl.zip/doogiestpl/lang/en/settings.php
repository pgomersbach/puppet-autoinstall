<?php
/**
 * English language file for Doogies blue Dokuwiki template configuration
 */

$lang['tabsPage']     = 'Name of page for tab navigation (leave empty to disable tabs)';
$lang['actionsToTop'] = 'Move the actions to the top?';
