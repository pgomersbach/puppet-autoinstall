<?php
/**
 * German language file for Doogies blue Dokuwiki template
 */

// label for drop down box at the bottom
$lang['more_actions'] = 'weitere Aktionen ...';
