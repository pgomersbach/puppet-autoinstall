<?php
/**
 * German language file for Doogies blue Dokuwiki template configuration
 */

$lang['tabsPage']     = 'Name der Seite für die Reiternavigation (leer lassen, um Funktion zu deaktivieren)';
$lang['actionsToTop'] = 'Die Werkzeuge nach oben verschieben?';
