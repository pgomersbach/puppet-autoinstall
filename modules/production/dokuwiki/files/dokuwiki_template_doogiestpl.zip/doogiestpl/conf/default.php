<?php
/* configuration for navbar in Doogies Template
 * (This is a piece of PHP code so PHP syntax applies!)
 */

$conf['tabsPage']     = 'tabs';
$conf['actionsToTop'] = 0;
