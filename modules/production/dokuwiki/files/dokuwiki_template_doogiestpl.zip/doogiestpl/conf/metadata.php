<?php
/* metadata for navbar configuration of Doogies Template
 * (This is a piece of PHP code so PHP syntax applies!)
 */

$meta['tabsPage']     = array('string');
$meta['actionsToTop'] = array('onoff');
