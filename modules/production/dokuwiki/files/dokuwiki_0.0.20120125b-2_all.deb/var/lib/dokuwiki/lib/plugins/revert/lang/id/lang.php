<?php
/**
 * Indonesian language file
 *
 * @author Irwan Butar Butar <irwansah.putra@gmail.com>
 * @author Yustinus Waruwu <juswaruwu@gmail.com>
 */
