<?php
/**
 * lb language file
 *
 * @author joel@schintgen.net
 */
