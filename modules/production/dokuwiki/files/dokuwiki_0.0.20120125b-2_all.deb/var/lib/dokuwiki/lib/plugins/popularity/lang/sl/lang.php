<?php
/**
 * Slovenian language file
 *
 * @author Matej Urbančič (mateju@svn.gnome.org)
 */
$lang['name']                  = 'Poročilo o uporabi (nalaganje strani je lahko dolgotrajno)';
$lang['submit']                = 'Pošlji podatke';
$lang['autosubmit']            = 'Samodejno pošlji podatke enkrat mesečno';
$lang['submissionFailed']      = 'Podatkov zaradi napake ni mogoče poslati:';
$lang['submitDirectly']        = 'Podatke je mogoče poslati ročno s pošiljanjem preko obrazca.';
$lang['autosubmitError']       = 'Zadnji poskus samodejnega pošiljanja je spodletel zaradi napake:';
$lang['lastSent']              = 'Podatki so bili uspešno poslani.';
