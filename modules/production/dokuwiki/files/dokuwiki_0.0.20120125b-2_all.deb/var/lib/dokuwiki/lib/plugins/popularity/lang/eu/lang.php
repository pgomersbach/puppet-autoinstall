<?php
/**
 * Basque language file
 *
 * @author Inko Illarramendi <inko.i.a@gmail.com>
 */
$lang['name']                  = 'Popularitate Feedback-a (denbora dezente iraun dezake kargatzen)';
$lang['submit']                = 'Datuak Bidali';
$lang['autosubmit']            = 'Automatikoki bidali informazioa hilabetean behin';
$lang['submissionFailed']      = 'Informazioa ezin izan da bidali ondorengo errorea dela eta:';
$lang['submitDirectly']        = 'Informazioa eskuz bidali dezakezu ondorengo formularioa bidaliz.';
$lang['autosubmitError']       = 'Azken bidalketa automatikoak huts egin zuen ondorengo errorea dela eta:';
$lang['lastSent']              = 'Informazioa bidalia izan da';
