<?php
/**
 * Serbian language file
 *
 * @author Иван Петровић petrovicivan@ubuntusrbija.org
 * @author Ivan Petrovic <petrovicivan@ubuntusrbija.org>
 * @author Miroslav Šolti <solti.miroslav@gmail.com>
 */
$lang['name']                  = 'Мерење популарности (може потрајати док се не учита)';
$lang['submit']                = 'Пошаљи податке';
