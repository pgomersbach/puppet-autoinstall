<?php
/**
 * Latin language file
 *
 * @author Massimiliano Vassalli <vassalli.max@gmail.com>
 */
$lang['name']                  = 'Index fauoris popularis (multum tempus quaerere potest)';
$lang['submit']                = 'Missum die';
$lang['autosubmit']            = 'Constanter res omni mense mittuntur';
$lang['submissionFailed']      = 'Res non mittuntur ea causa:';
$lang['submitDirectly']        = 'Res tu mittere potes cum hoc exemplar compleas.';
$lang['autosubmitError']       = 'Extrema missio lapsa est ea causa:';
$lang['lastSent']              = 'Res missae sunt';
