<?php
/**
 * idni language file
 *
 * @author Harefa <fidelis@harefa.com>
 * @author Yustinus Waruwu <juswaruwu@gmail.com>
 */
