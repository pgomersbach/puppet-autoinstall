<?php
/**
 * Turkish language file
 *
 * @author Aydın Coşkuner <aydinweb@gmail.com>
 * @author Cihan Kahveci <kahvecicihan@gmail.com>
 * @author Yavuz Selim <yavuzselim@gmail.com>
 * @author Caleb Maclennan <caleb@alerque.com>
 */
$lang['name']                  = 'Popülerlik Geribeslemesi (yüklemesi uzun sürebilir)';
$lang['submit']                = 'Verileri Gönder';
