<?php
/**
 * Interlingua language file
 *
 * @author robocap <robocap1@gmail.com>
 * @author Martijn Dekker <martijn@inlv.org>
 */
$lang['name']                  = 'Datos de popularitate (pote prender alcun tempore pro cargar)';
$lang['submit']                = 'Inviar datos';
