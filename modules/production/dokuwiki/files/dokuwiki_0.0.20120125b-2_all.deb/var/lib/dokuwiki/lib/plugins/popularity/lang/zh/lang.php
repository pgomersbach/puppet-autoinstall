<?php
/**
 * Chinese language file
 *
 * @author ZDYX <zhangduyixiong@gmail.com>
 * @author http://www.chinese-tools.com/tools/converter-tradsimp.html
 * @author George Sheraton guxd@163.com
 * @author Simon zhan <simonzhan@21cn.com>
 * @author mr.jinyi@gmail.com
 * @author ben <ben@livetom.com>
 * @author lainme <lainme993@gmail.com>
 * @author caii <zhoucaiqi@gmail.com>
 * @author Hiphen Lee <jacob.b.leung@gmail.com>
 * @author caii, patent agent in China <zhoucaiqi@gmail.com>
 * @author lainme993@gmail.com
 * @author Shuo-Ting Jian <shoting@gmail.com>
 */
$lang['name']                  = '人气反馈（载入可能需要一些时间）';
$lang['submit']                = '发送数据';
$lang['autosubmit']            = '每月自动发送';
$lang['submissionFailed']      = '数据由于以下原因不恩你给发送：';
$lang['submitDirectly']        = '你可以手动提交下面的表单来发送数据。';
$lang['autosubmitError']       = '印以下原因，上一次自动提交失败：';
$lang['lastSent']              = '数据已发送';
