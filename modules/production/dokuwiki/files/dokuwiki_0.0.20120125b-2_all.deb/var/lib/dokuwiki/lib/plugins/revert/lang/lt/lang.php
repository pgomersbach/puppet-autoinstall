<?php
/**
 * Lithuanian language file
 *
 * @author audrius.klevas@gmail.com
 * @author Arunas Vaitekunas <aras@fan.lt>
 */
