<?php
/**
 * Estonian language file
 *
 * @author kristian.kankainen@kuu.la
 * @author Rivo Zängov <eraser@eraser.ee>
 */
