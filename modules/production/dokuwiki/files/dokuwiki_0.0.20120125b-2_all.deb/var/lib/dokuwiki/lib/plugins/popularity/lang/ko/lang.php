<?php
/**
 * Korean language file
 *
 * @author jk lee
 * @author dongnak@gmail.com
 * @author Song Younghwan <purluno@gmail.com>
 * @author SONG Younghwan <purluno@gmail.com>
 * @author Seung-Chul Yoo  <dryoo@live.com>
 */
$lang['name']                  = '인기도 조사 (불러오는데 시간이 걸릴 수 있습니다.)';
$lang['submit']                = '자료 보내기';
$lang['autosubmit']            = '자료를 자동으로 매달 한번씩 보내기';
$lang['submissionFailed']      = '다음과 같은 이유로 자료 전송에 실패했습니다 :';
$lang['submitDirectly']        = '아래의 양식에 맞춰 수동으로 작성된 자료를 보낼 수 있습니다';
$lang['autosubmitError']       = '다음과 같은 이유로 자동 자료 전송에 실패했습니다 :';
$lang['lastSent']              = '자료가 전송되었습니다';
