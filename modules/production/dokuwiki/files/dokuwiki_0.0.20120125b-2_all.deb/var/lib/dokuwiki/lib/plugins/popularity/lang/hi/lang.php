<?php
/**
 * Hindi language file
 *
 * @author Abhinav Tyagi <abhinavtyagi11@gmail.com>
 * @author yndesai@gmail.com
 */
$lang['submit']                = 'डेटा भेजे';
