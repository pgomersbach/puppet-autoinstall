<?php
/**
 * Valencian language file
 *
 * @author Bernat Arlandis <berarma@ya.com>
 * @author Bernat Arlandis <berarma@llenguaitecnologia.com>
 */
$lang['name']                  = 'Retro-alimentació de popularitat (pot tardar un poc en carregar)';
$lang['submit']                = 'Enviar senyes';
