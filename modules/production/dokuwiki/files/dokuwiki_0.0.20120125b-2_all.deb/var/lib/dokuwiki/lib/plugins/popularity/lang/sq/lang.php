<?php
/**
 * Albanian language file
 *
 * @author Leonard Elezi leonard.elezi@depinfo.info
 */
$lang['name']                  = 'Informacioni mbi Popullaritetin (mund të marë ca kohë derisa të ngarkohet)';
$lang['submit']                = 'Dërgo Të Dhënat';
