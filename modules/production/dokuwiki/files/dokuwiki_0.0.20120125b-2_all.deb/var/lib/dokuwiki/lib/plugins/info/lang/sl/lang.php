<?php
/**
 * English language file
 *
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * @author     Guillaume Turri <guillaume.turri@gmail.com>
 */
 
$lang['encoding']              = 'utf-8';
$lang['direction']             = 'ltr';
$lang['onHidden']              = 'Click to display ⇲';
$lang['onVisible']             = 'Click to hide ⇱';
