<?php
/**
 * Indonesian language file
 *
 * @author Yustinus Waruwu <juswaruwu@gmail.com>
 */
