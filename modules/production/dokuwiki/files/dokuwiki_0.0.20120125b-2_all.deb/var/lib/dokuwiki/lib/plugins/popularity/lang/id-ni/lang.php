<?php
/**
 * idni language file
 *
 * @author Harefa <fidelis@harefa.com>
 * @author Yustinus Waruwu <juswaruwu@gmail.com>
 */
$lang['name']                  = 'Sabölö teturia (sito\'ölönia ara ginötö wamokai)';
$lang['submit']                = 'Fa\'ohe\'ö data';
