<?php
/**
 * kazakh language file
 *
 * @author Nurgozha Kaliaskarov astana08@gmail.com
 */
