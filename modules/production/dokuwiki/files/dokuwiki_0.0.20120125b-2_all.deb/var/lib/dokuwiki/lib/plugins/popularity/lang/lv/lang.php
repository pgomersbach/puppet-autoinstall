<?php
/**
 * Latvian, Lettish language file
 *
 * @author Aivars Miška <allefm@gmail.com>
 */
$lang['name']                  = 'Popularitātes atsauksmes (ielāde var aizņemt kādu laiku)';
$lang['submit']                = 'Nosūtīt datus';
$lang['autosubmit']            = 'Automātiski reizi mēnesī nosūtīt datus';
$lang['submissionFailed']      = 'Datus nevar nosūtīt kļūdas dēļ:';
$lang['submitDirectly']        = 'Jūs pats varat pats nosūtīt datus no šīs veidlapas.';
$lang['autosubmitError']       = 'Pēdējā automātiskā nosūtīšana kļūdas dēļ:';
$lang['lastSent']              = 'Dati nosūtīti';
