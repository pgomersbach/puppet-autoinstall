package Crypt::SSLeay::Conn;
require Crypt::SSLeay;
use strict;
1;
