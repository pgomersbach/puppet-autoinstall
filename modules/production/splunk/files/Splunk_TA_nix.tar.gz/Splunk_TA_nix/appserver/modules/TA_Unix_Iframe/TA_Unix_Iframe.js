Splunk.namespace("Module");
Splunk.Module.TA_Unix_IFrame = $.klass(Splunk.Module.IFrameInclude, {

    initialize: function($super, container){
        $super(container);
    }   
});

